28 Oktober 2015
Tugas 2 PPW - AJAX dan Web Storage
George Albert - 1406569781

- Cara mengakses Tugas 2 adalah kawung.cs.ui.ac.id/~george.albert/tugas2 atau kawung.mhs.cs.ui.ac.id/~george.albert/tugas2

- Halaman yang diimplementasikan fitur load posts dari JSON adalah index.html

- Halaman-halaman yang sudah diimplementasi fitur post display comments menggunakan JSON dan Web Storage adalah "XML Table" (pages/posts/16XmlTable.html) dan "The Nth Post" (pages/posts/15TheNthPost.html)

- Halaman-halaman yang diimplementasi fitur ambil data dari XML untuk tabel adalah halaman "XML Table" diatas

- Hasil soal bonus dapat dilihat di sidebar kanan, kotak yang kedua.

- Laporan alidasi JSHint yang mungkin perlu diperhatikan hanya karena ada function dalam loop, namun itu memang diperlukan karena perlu diiterasi elemen-elemen dalam node-node tersebut. Diasumsikan  jQuery dan "ignore unused variables" krn external js memakai method dari luar.

------

- Code yang dipakai untuk source code javascript banyak mengambil dari sumber yang sama seperti UTS. Adapun kode sumber yang dipakai pada UTS antara lain:

> http://stackoverflow.com/questions/18884840/adding-a-new-array-element-to-a-json-object
> http://stackoverflow.com/questions/16417211/load-xml-file-content-into-div-using-jquery
> http://stackoverflow.com/questions/19632439/how-to-match-credentails-using-xml-on-login-html-page
> http://stackoverflow.com/questions/17003334/create-a-empty-json-object-from-an-existing-json-object-array
> http://stackoverflow.com/questions/7346563/loading-local-json-file
> http://stackoverflow.com/questions/10211145/getting-current-date-and-time-in-javascript
> http://stackoverflow.com/questions/2010892/storing-objects-in-html5-localstorage
> http://stackoverflow.com/questions/2342371/jquery-loop-on-json-data-using-each