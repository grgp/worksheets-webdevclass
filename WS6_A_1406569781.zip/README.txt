5 November 2015
WS 6 PPW - PHP Validation
George Albert - 1406569781

- Cara mengakses WS 6 adalah kawung.cs.ui.ac.id/~george.albert/ws6 atau kawung.mhs.cs.ui.ac.id/~george.albert/ws6

- Halaman yang diimplementasikan fitur validasi adalah halaman "XML Table", bisa diakses dari sidebar index.html, dan punya link di /pages/posts/16XmlTable.php

- Halaman-halaman selain itu tidak diimplementasikan

- Soal bonus dikerjakan karena langsung menampilkan comment setelah post

- Agar PHP bisa dijalankan harus dijalankan melalui server atau localhost

------

- Code yang dipakai untuk source code berasal dari w3schools bagian PHP validation dan beberapa pertanyaan stack overflow